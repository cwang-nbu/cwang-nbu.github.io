---
# Display name
title: 郑瑜杰
weight: 202110

# Username (this should match the folder name)
authors:
- 2021_YJ_Zheng

# Is this the primary user of the site?
superuser: false

# Role/position
role: 硕士生

# Organizations/Affiliations
organizations:
- name: 宁波大学
  url: "https://www.nbu.edu.cn/en/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests include deep learning.

interests:
- 网络轻量化


education:
  courses:
  - course: 工学硕士，计算机技术
    institution:  宁波大学
    year: 2021-2024
  - course: 理学学士，信息与计算科学
    institution: 浙江工业大学
    year: 2017-2021

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: 'mailto:wangchong@nbu.edu.cn'  # For a direct email link, use "mailto:test@example.org".
- icon: orcid
  icon_pack: ai
  link: https://orcid.org/0000-0001-6016-6545
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.com/citations?user=A9rwcNoAAAAJ&hl=zh-CN
- icon: github
  icon_pack: fab
  link: https://github.com/cwang-nbu
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- 毕业生

---
**毕业去向：**

华为技术有限公司，算法工程师


**实习经历：**


**乐歌人体工学科技股份有限公司| LOCTEK**， 实习生， 2022.08-2023.08

主要负责基于骨架检测的智能升降桌项目，该项目利用人体骨架检测技术，检测人体骨架关键点在三维空间中的位置，并根据这些关键点的位置和人体工学规则确定升降桌的升降高度，最后利用程序控制桌面自动升降至合适的高度，实现了完全的自动化与智能化。我们所设计的系统流程和工作内容如下：
1. 利用双目相机采集用户的RGB图像
2. 使用人体骨架检测模型PoseNet提取左右相机图像中的人体二维关键点坐标
3. 根据左右关键点之间的视差计算每个关键点到相机的距离，从而得到人体的三维关键点坐标
4. 进行坐标系的转换，将像素坐标系的坐标映射至世界坐标系，以统一人体关键点各个坐标的单位
5. 根据人体关键点的三维坐标估算人体手臂夹角度数，若度数超过一定范围，则说明升降桌需要进行一定的调整以确保人体坐姿符合人体工学的要求


**科研经历：**

知识蒸馏


● 提出了基于师生能力匹配的离线蒸馏方法。通过在训练过程中将学生网络的卷积层扩展为多分支结构，以缩小容量差距。在训练结束后对学生模型的结构进行等价转换，以避免额外分支带来的推理开销。同时，引入置信度匹配策略以自适应地缩放师生网络的 logits 来缩小置信度差距。

相关论文Enlightening the Student in Knowledge Distillation 已被 IEEE International Conference on Acoustics, Speech and Signal Processing 2023 (ICASSP 2023, CCF B)接收，
代码地址：https://github.com/YujieZheng99/KDrefine

● 提出了基于全网络-子网络能力匹配的自蒸馏方法。通过结构扩张策略将原始网络扩展为一个多分支的结构，以构建一个更强大的全网络作为教师，并在训练结束后实现结构的等价转化。在训练过程中，通过随机丢弃教师的额外分支来生成多样化的子网络作为学生。同时，提出了一种随机特征混合策略，通过一个随机插入到教师与学生网络中间层的特征混合模块，将知识蒸馏过程引入到混合特征空间中。

相关论文Restructuring the Teacher and Student in Self-Distillation 已被 IEEE Transactions on Image Processing (TIP , SCI-1区)接收，
代码地址：https://github.com/YujieZheng99/RSD