---
# Display name
title: 陈炳灿
weight: 202509

# Username (this should match the folder name)
authors:
- 2025_BC_Chen

# Is this the primary user of the site?
superuser: false

# Role/position
role: 硕士生

# Organizations/Affiliations
organizations:
- name: 宁波大学
  url: "https://www.nbu.edu.cn/en/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests include computer vision, especially video anomaly detection and behavior recognition.

interests:
- 视频异常检测

education:
  courses:
  - course: 工学学士，计算机科学与技术
    institution: 宁波大学
    year: 2021-2025

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: 'mailto:wangchong@nbu.edu.cn'  # For a direct email link, use "mailto:test@example.org".
- icon: orcid
  icon_pack: ai
  link: https://orcid.org/0000-0001-6016-6545
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.com/citations?user=A9rwcNoAAAAJ&hl=zh-CN
- icon: github
  icon_pack: fab
  link: https://github.com/cwang-nbu
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- 在校生

---




**科研经历：**

视频异常检测